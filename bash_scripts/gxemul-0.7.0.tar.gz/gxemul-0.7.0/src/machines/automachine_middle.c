
/*
 *  automachine_init():
 */
void automachine_init(void)
{
	/*  printf("automachine_init()\n");  */

	/*  automachine_middle.c ends here.  */

