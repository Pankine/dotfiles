
/*
 *  autodev_init():
 */
void autodev_init(void)
{
	/*  printf("autodev_init()\n");  */

	/*  autodev_middle.c ends here.  */

